{
  "author": "20220615",
  "name": "晗剧",
  "url": "https://www.hanju.fun", //填网站链接
  "tihuan": "cnzz.com", //这个不用动，是个别网站嗅探时过滤地址用的
  "User": "空", //这个不用动，是个别网站播放需要请求头时才用到
  "shouye": "1",

  "fenlei": "电影$/vodshow/id/1/page/#剧集$/vodshow/id/2/page/#综艺$/vodshow/id/3/page/#动漫$/vodshow/id/4/page/#国产剧$/vodshow/area/内地/id/2/page/#韩国剧$/vodshow/area/韩国/id/2/page/#美国剧$/vodshow/area/美国/id/2/page/#英国剧$/vodshow/area/英国/id/2/page/#日本剧$/vodshow/area/日本/id/2/page/#香港剧$/vodshow/area/香港/id/2/page/#台湾剧$/vodshow/area/台湾/id/2/page/#泰国剧$/vodshow/area/泰国/id/2/page/#国产动漫$/vodshow/area/国产/id/4/page/#日本动漫$/vodshow/area/日本/id/4/page/#欧美动漫$/vodshow/area/欧美/id/4/page/#动画片$/vodshow/class/动画/id/1/page/#儿童片$/vodshow/class/儿童/id/1/page/#喜剧片$/vodshow/class/喜剧/id/1/page/#爱情片$/vodshow/class/爱情/id/1/page/#恐怖片$/vodshow/class/恐怖/id/1/page/#动作片$/vodshow/class/动作/id/1/page/#科幻片$/vodshow/class/科幻/id/1/page/#剧情片$/vodshow/class/剧情/id/1/page/#战争片$/vodshow/class/战争/id/1/page/#犯罪片$/vodshow/class/犯罪/id/1/page/#奇幻片$/vodshow/class/奇幻/id/1/page/#武侠片$/vodshow/class/武侠/id/1/page/#冒险片$/vodshow/class/冒险/id/1/page/#枪战片$/vodshow/class/枪战/id/1/page/#悬疑片$/vodshow/class/悬疑/id/1/page/#惊悚片$/vodshow/class/惊悚/id/1/page/#青春片$/vodshow/class/青春/id/1/page/#古装片$/vodshow/class/古装/id/1/page/#历史片$/vodshow/class/历史/id/1/page/#运动片$/vodshow/class/运动/id/1/page/#网络电影$/vodshow/class/网络电影/id/1/page/", //网站列表的分类
  "houzhui": ".html", //网站翻页链接的后缀

  "shifouercijiequ": "1", //截取的列表数组是否需要二次截取，0不需要，1需要
  "jiequqian": "class=\"module-items", //不需要二次截取就填空
  "jiequhou": "class=\"fixedGroup", //不需要二次截取就填空
  "jiequshuzuqian": "<a", //截取的列表数组的前关键词,截取的关键词有 " 的用 \ 进行转义
  "jiequshuzuhou": "alt=\"", //截取的列表数组的后关键词,截取的关键词有 " 的用 \ 进行转义
  "tupianqian": "data-original=\"", //列表中资源的图片前关键词,截取的关键词有 " 的用 \ 进行转义
  "tupianhou": "\"", //列表中资源的图片后关键词,截取的关键词有 " 的用 \ 进行转义
  "biaotiqian": "title=\"", //列表中资源的标题前关键词,截取的关键词有 " 的用 \ 进行转义
  "biaotihou": "\"", //列表中资源的标题后关键词,截取的关键词有 " 的用 \ 进行转义
  "lianjieqian": "href=\"", //列表中资源的详情页跳转链接前关键词,截取的关键词有 " 的用 \ 进行转义
  "lianjiehou": "\"", //列表中资源的详情页跳转链接后关键词,截取的关键词有 " 的用 \ 进行转义

  //搜索部分基本不用动，现在网站基本都是苹果CMS，所有搜索是固定的。
  "sousuoqian": "/index.php/ajax/suggest?mid=1&wd=",
  "sousuohou": "&limit=500",
  "sousuohouzhui": "/voddetail/", //搜索页影片跳转详情页的中间标识链接部分
  "ssmoshi": "0",
  "sousuoshifouercijiequ": "0",
  "jspic": "pic",
  "jsname": "name",
  "jsid": "id",
  "ssjiequqian": "空",
  "ssjiequhou": "空",
  "ssjiequshuzuqian": "空",
  "ssjiequshuzuhou": "空",
  "sstupianqian": "空",
  "sstupianhou": "空",
  "ssbiaotiqian": "空",
  "ssbiaotihou": "空",
  "sslianjieqian": "空",
  "sslianjiehou": "空",

  "bfshifouercijiequ": "0",
  "bfjiequqian": "空",
  "bfjiequhou": "空",
  "bfjiequshuzuqian": "class=\"module-play-list\"", //播放截取的列表数组的前关键词
  "bfjiequshuzuhou": "</div>", //播放截取的列表数组的后关键词

  "zhuangtaiqian": "更新：</span>", //状态前关键词
  "zhuangtaihou": "</div>", //状态后关键词
  "daoyanqian": "导演：</span>", //导演前关键词
  "daoyanhou": "</div>", //导演态后关键词
  "zhuyanqian": "主演：</span>", //主演前关键词
  "zhuyanhou": "</div>", //主演后关键词
  "juqingqian": "introduction-content\"><p>", //剧情前关键词
  "juqinghou": "</p>", //剧情后关键词

  "bfyshifouercijiequ": "0", //截取的播放列表数组是否需要二次截取，0不需要，1需要
  "bfyjiequqian": "空", //不需要二次截取就填空
  "bfyjiequhou": "空", //不需要二次截取就填空
  "bfyjiequshuzuqian": "<a", //播放剧集数组前关键词
  "bfyjiequshuzuhou": "/a>", //播放剧集数组后关键词
  "bfbiaotiqian": "span>", //播放剧集标题前关键词
  "bfbiaotihou": "</span", //状播放剧集标题后关键词
  "bflianjieqian": "href=\"", //播放剧集链接前关键词
  "bflianjiehou": "\""
} //播放剧集链接后关键词
